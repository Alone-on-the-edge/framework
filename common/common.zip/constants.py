import sys
sys.path.append("d:\Project\ssot")

GG_ILLEGAL_VS_REPLACED_CHAR = {
    '$', '__DOL'
}